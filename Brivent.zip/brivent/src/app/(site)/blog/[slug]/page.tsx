import { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { buildMetadata } from "@/lib/metadata";
import { blogPosts, blogCategories } from "@/data/blog";
import {
  formatDate,
  getRelatedPosts,
  slugifyCategory,
  categoryFromSlug,
} from "@/lib/utils";
import Container from "@/components/shared/Container";
import BlogCard from "@/components/shared/BlogCard";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  const postSlugs = blogPosts.map((post) => ({ slug: post.slug }));
  const categorySlugs = blogCategories.map((cat) => ({
    slug: slugifyCategory(cat.label),
  }));
  return [...postSlugs, ...categorySlugs];
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);

  if (post) {
    return buildMetadata({
      title: post.seoTitle ?? post.title,
      description: post.seoDescription ?? post.excerpt,
      path: `/blog/${post.slug}`,
      ogImage: post.ogImage,
    });
  }

  const categoryLabels = blogCategories.map((c) => c.label);
  const category = categoryFromSlug(slug, categoryLabels);

  if (category) {
    return buildMetadata({
      title: `${category} — Insights`,
      description: `${category} stories and updates from Brivent.`,
      path: `/blog/${slug}`,
    });
  }

  return buildMetadata({
    title: "Insights",
    description: "Stories and updates from Brivent.",
    path: `/blog/${slug}`,
  });
}

function CategoryPage({ category }: { category: string }) {
  const categoryMeta = blogCategories.find((c) => c.label === category);
  const posts = blogPosts.filter((post) => post.category === category);

  return (
    <main>
      <section className="relative bg-dark-bg pt-40 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(21,43,249,0.1),_transparent_60%)] pointer-events-none" />

        <Container className="relative text-center max-w-3xl mx-auto">
          <p className="text-accent text-[10px] tracking-widest uppercase font-semibold mb-4">
            Insights
          </p>
          <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight tracking-tight mb-6">
            For <span className="text-accent">{category}</span>
          </h1>
          {categoryMeta?.description && (
            <p className="text-white/60 text-lg leading-relaxed">
              {categoryMeta.description}
            </p>
          )}
        </Container>
      </section>

      <section className="bg-white py-20">
        <Container>
          {posts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts.map((post) => (
                <BlogCard key={post.slug} post={post} />
              ))}
            </div>
          ) : (
            <div className="border border-dashed border-border rounded-xl p-12 text-center">
              <p className="text-sm text-muted-light">
                No posts in this category yet. Check back soon.
              </p>
            </div>
          )}
        </Container>
      </section>
    </main>
  );
}

function ArticlePage({ post }: { post: (typeof blogPosts)[number] }) {
  const related = getRelatedPosts(blogPosts, post.slug);

  return (
    <main className="pt-20">
      <section className="bg-accent py-4">
        <Container>
          <nav className="flex items-center gap-2 text-sm text-white/90 flex-wrap">
            <Link href="/blog" className="hover:text-white transition-colors flex items-center gap-1">
              ← Blog
            </Link>
            <span>&gt;</span>
            <Link
              href={`/blog/${slugifyCategory(post.category)}`}
              className="hover:text-white transition-colors"
            >
              {post.category}
            </Link>
            <span>&gt;</span>
            <span className="text-white font-medium truncate">{post.title}</span>
          </nav>
        </Container>
      </section>

      <section className="bg-surface pt-10 pb-16 text-center">
        <Container className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight tracking-tight mb-6">
            {post.title}
          </h1>
          <p className="text-muted text-base">
            Created on {formatDate(post.publishedAt)}
          </p>
        </Container>
      </section>

      <Container className="pb-4">
        <div className="relative w-full aspect-[16/9] md:aspect-[21/10] overflow-hidden">
          <img
            src="/images/blog/image.png"
            alt={post.title}
            className="w-full h-full object-cover"
          />
        </div>
      </Container>

      <section className="bg-white py-20 border-b border-border">
        <Container>
          <article className="prose prose-slate max-w-3xl mx-auto text-base text-muted leading-relaxed whitespace-pre-wrap">
            {post.content}
          </article>
        </Container>
      </section>

      {related.length > 0 && (
        <section className="bg-surface py-24">
          <Container>
            <p className="text-[10px] text-accent tracking-widest uppercase font-semibold mb-8">
              Related posts
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {related.map((relatedPost) => (
                <BlogCard key={relatedPost.slug} post={relatedPost} />
              ))}
            </div>
          </Container>
        </section>
      )}
    </main>
  );
}

export default async function BlogSlugPage({ params }: Props) {
  const { slug } = await params;

  const post = blogPosts.find((p) => p.slug === slug);
  if (post) {
    return <ArticlePage post={post} />;
  }

  const categoryLabels = blogCategories.map((c) => c.label);
  const category = categoryFromSlug(slug, categoryLabels);
  if (category) {
    return <CategoryPage category={category} />;
  }

  notFound();
}