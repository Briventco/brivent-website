import { BlogCategory, BlogPost } from "@/types/blog";

export const blogCategories: { label: BlogCategory; description: string }[] = [
  { label: "Company", description: "Milestones, announcements, and stories." },
  { label: "Product", description: "Product launches, updates, and lessons." },
  { label: "Engineering", description: "Technical work and engineering lessons." },
  { label: "AI", description: "Practical applications of artificial intelligence." },
  { label: "Partnerships", description: "Collaboration announcements and stories." },
  { label: "Community", description: "Events, people, and ecosystem activity." },
];

export const blogPosts: BlogPost[] = [
  {
    slug: "building-brivent",
    title: "Building Brivent",
    excerpt:
      "Every company starts with a problem it wants to solve. For Brivent, the problem was bigger than simply building software.",
    category: "Company",
    tags: ["Company", "Servra", "Kinnoc", "BIIT"],
    author: "Brivent Team",
    publishedAt: "2026-08-19",
    readingTime: "8 min read",
    coverImage: "/images/blog/image.png",
    content: `Every company starts with a problem it wants to solve.

For Brivent, the problem was bigger than simply building software.

We wanted to build technology that solves real problems, create products that people can actually use, and build a company capable of growing ideas from Africa into meaningful businesses and platforms.

That is what Brivent is becoming.

## Building Brivent

Brivent Global Innovations Limited is a technology company focused on building digital solutions for businesses while developing and owning products of its own.

The company was founded by Oyindamola Caleb Abisoye alongside co-founder Oludare Deborah, with a growing team of engineers, operators, and contributors helping turn ideas into working technology.

Our work sits across two important areas: building technology for others and building products of our own.

On one side, we work with businesses and organisations to design and develop digital solutions that help them operate, communicate, and grow.

On the other, we build and develop products that address problems we believe are worth solving.

## Products We Are Building

Brivent currently has two major products: Servra and Kinnoc.

### Servra

Servra is an AI Order Agent built for businesses that take orders through WhatsApp.

Instead of asking customers to download another application or move to another platform, Servra works directly through a business's existing WhatsApp number.

It can respond to customers, share menus, take orders, calculate totals, and notify the business when an order is ready for confirmation.

The idea is simple:

**Chat. Order. Done.**

Servra represents one of Brivent's core beliefs — technology should fit into the way people already work rather than forcing them to completely change their behaviour.

### Kinnoc

Kinnoc is a community platform built to bring communities, events, opportunities, and resources together in one place.

The idea behind Kinnoc is straightforward: there are countless communities, events, opportunities, and resources around us, but discovering and staying connected to them can be difficult.

Kinnoc is being built to make that experience easier.

It gives people a place to discover communities they can belong to, find events and opportunities, and stay connected to the things that matter to them.

Kinnoc is currently being developed as part of Brivent's growing product portfolio.

## More Than Products

While products are an important part of Brivent, we believe technology companies are also built around people.

That belief led to the growth of Be Involved in Tech (BIIT), our technology community focused on connecting people, creating opportunities, and encouraging more people to participate in technology.

BIIT has grown beyond simply being a community. It has become a platform through which we connect with students, builders, founders, and other people interested in technology and innovation.

## Showing Up for the Ecosystem

Our work in technology has also taken us into spaces where ideas, innovation, and entrepreneurship are being celebrated.

In 2025, BIIT was one of the sponsors of TEDxUNIOSUN, supporting an event that brought together people with ideas, stories, and perspectives worth sharing.

Kinnoc also supported the Hult Prize UNIOSUN Chapter, a student-focused innovation and entrepreneurship initiative.

The Hult Prize is one of the world's largest student innovation programmes, giving young people an opportunity to develop ideas that address real-world problems.

For us, supporting initiatives like these is not simply about putting our name on an event.

It is about being part of the ecosystem we want to see grow.

It is about creating room for young people to build, experiment, learn, and turn their ideas into something real.

## From Ideas to Execution

One of the things we are learning as we build Brivent is that having an idea is only the beginning.

A product needs people.

People need systems.

Systems need structure.

And structure needs a company willing to keep learning and improving.

That is why we are intentionally building Brivent beyond individual projects.

We are building processes, developing our team, strengthening partnerships, and creating an environment where ideas can move from conversations to prototypes, products, and businesses.

## The People Behind Brivent

Brivent is being built by a growing team of founders, engineers, operators, and contributors.

Our engineering team works across frontend, backend, mobile development, quality assurance, and the infrastructure required to turn product ideas into functioning technology.

Our operations and leadership functions help coordinate projects, partnerships, communities, and the systems that keep the company moving.

Everyone plays a different role, but the objective remains the same:

**Build meaningful technology.**

## What Comes Next

Brivent is still early.

There is a lot we are still figuring out, a lot we are still building, and a lot more we want to accomplish.

But that is also what makes this stage exciting.

We are building from Africa, working with people and businesses around us, creating products of our own, and learning what it takes to build a technology company that can last.

There will be new products.

There will be new partnerships.

There will be new people joining the team.

There will be mistakes, experiments, launches, and lessons along the way.

And we intend to document the journey.

This is Brivent.

We are building.`,
    seoTitle: "Building Brivent — Our Story",
    seoDescription:
      "The story of Brivent Global Innovations — why we started, the products we're building (Servra and Kinnoc), and what comes next.",
  },
];