"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import Container from "@/components/shared/Container";
import SectionHeading from "@/components/shared/SectionHeading";
import BlogCard from "@/components/shared/BlogCard";
import { blogPosts, blogCategories } from "@/data/blog";
import { slugifyCategory } from "@/lib/utils";

function LinePattern() {
  return (
    <svg
      className="absolute inset-0 w-full h-full opacity-[0.15] pointer-events-none"
      preserveAspectRatio="xMidYMid slice"
      viewBox="0 0 800 400"
      aria-hidden="true"
    >
      <defs>
        <pattern
          id="blog-hero-lines"
          x="0"
          y="0"
          width="120"
          height="120"
          patternUnits="userSpaceOnUse"
          patternTransform="rotate(15)"
        >
          <line x1="0" y1="60" x2="120" y2="60" stroke="var(--accent)" strokeWidth="1" />
          <line x1="60" y1="0" x2="60" y2="120" stroke="var(--accent)" strokeWidth="1" />
        </pattern>
      </defs>
      <rect width="800" height="400" fill="url(#blog-hero-lines)" />
    </svg>
  );
}

export function BlogHero() {
  return (
    <section className="relative bg-surface pt-40 pb-20 overflow-hidden">
      <LinePattern />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-surface pointer-events-none" />

      <Container className="relative z-10 text-center max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <p className="text-accent text-xs tracking-[0.2em] font-semibold uppercase mb-6">
            Insights
          </p>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground leading-[1.1] tracking-tight mb-6">
            Ideas, products, lessons, and{" "}
            <span className="text-accent">stories from Brivent.</span>
          </h1>
          <p className="text-muted text-lg leading-relaxed max-w-2xl mx-auto">
            Follow what we are building, what we are learning, and how we
            think about technology.
          </p>
        </motion.div>
      </Container>
    </section>
  );
}

export function Categories() {
  return (
    <section className="bg-white py-16 border-b border-border">
      <Container>
        <div className="flex flex-wrap justify-center gap-3">
          {blogCategories.map((cat) => (
            <Link
              key={cat.label}
              href={`/blog/${slugifyCategory(cat.label)}`}
              className="text-xs font-medium text-muted border border-border rounded-full px-4 py-2 hover:border-accent hover:text-accent transition-colors"
              title={cat.description}
            >
              {cat.label}
            </Link>
          ))}
        </div>
      </Container>
    </section>
  );
}

function formatDate(date: string | Date) {
  const d = new Date(date);
  return d.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

function DotWorldMap() {
  return (
    <div
      className="absolute inset-0 opacity-30"
      style={{
        backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.35) 1.5px, transparent 1.5px)",
        backgroundSize: "7px 7px",
        maskImage: "url('/images/world-map.svg')",
        WebkitMaskImage: "url('/images/world-map.svg')",
        maskRepeat: "no-repeat",
        WebkitMaskRepeat: "no-repeat",
        maskPosition: "center",
        WebkitMaskPosition: "center",
        maskSize: "75% auto",
        WebkitMaskSize: "75% auto",
      }}
    />
  );
}

export function GlobalSection() {
  return (
    <section className="mt-24 mb-20">
      <div className="relative overflow-hidden rounded-[28px] bg-[#210b5c] min-h-[360px]">
        <DotWorldMap />

        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#210b5c]/40" />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-full px-6 text-center"
        >
          <p className="!text-center text-[#00AEEF] text-xs md:text-sm font-semibold tracking-[0.45em] uppercase mb-5">
            WE ARE GLOBAL
          </p>

          <h2 className="!text-center text-white text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight mb-7">
            Let's Build the future together
          </h2>

          <a
            href="/contact"
            className="inline-flex items-center justify-center px-8 py-3 rounded-xl bg-white/20 border border-white/50 text-white font-semibold text-sm md:text-base backdrop-blur-sm shadow-lg transition-all duration-300 hover:bg-white/30 hover:border-white hover:-translate-y-0.5"
          >
            Build With Us
          </a>
        </motion.div>
      </div>
    </section>
  );
}

export function LatestPosts() {
  const featuredPost = blogPosts[0];
  const remainingPosts = blogPosts.slice(1);

  return (
    <section className="bg-surface py-24">
      <Container>
        {featuredPost && (
          <>
            <div className="text-center max-w-4xl mx-auto mb-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              >
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight tracking-tight mb-4">
                  {featuredPost.title}
                </h2>
                <p className="text-lg text-muted mb-2">{featuredPost.excerpt}</p>
                <p className="text-muted text-sm">
                  Created on {formatDate(featuredPost.publishedAt)}
                </p>
              </motion.div>
            </div>

            {featuredPost.coverImage && (
              <div className="relative w-full aspect-[16/9] md:aspect-[21/10] overflow-hidden rounded-lg mb-12">
                <img
                  src={featuredPost.coverImage}
                  alt={featuredPost.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="max-w-4xl mx-auto prose prose-slate text-base text-muted leading-relaxed">
              {/* {featuredPost.content.split("\n").map((paragraph, index) => { */}
              {featuredPost.content.split("\n").map((paragraph: string, index: number) => {
                if (paragraph.trim() === "") return null;
                if (paragraph.startsWith("#### ")) {
                  return (
                    <h4 key={index} className="text-lg font-bold mt-4 mb-2">
                      {paragraph.replace("#### ", "")}
                    </h4>
                  );
                }
                if (paragraph.startsWith("### ")) {
                  return (
                    <h3 key={index} className="text-xl font-bold mt-5 mb-2">
                      {paragraph.replace("### ", "")}
                    </h3>
                  );
                }
                if (paragraph.startsWith("## ")) {
                  return (
                    <h2 key={index} className="text-2xl font-bold mt-6 mb-3">
                      {paragraph.replace("## ", "")}
                    </h2>
                  );
                }
                if (paragraph.startsWith("# ")) {
                  return (
                    <h1 key={index} className="text-3xl font-bold mt-8 mb-4">
                      {paragraph.replace("# ", "")}
                    </h1>
                  );
                }
                if (paragraph.startsWith("**") && paragraph.endsWith("**")) {
                  return (
                    <p key={index} className="font-bold mb-4">
                      {paragraph.replace(/\*\*/g, "")}
                    </p>
                  );
                }
                if (paragraph.startsWith("---")) {
                  return <hr key={index} className="my-8 border-t border-border" />;
                }
                return (
                  <p key={index} className="mb-4">
                    {paragraph}
                  </p>
                );
              })}
            </div>
          </>
        )}

        <GlobalSection />

        <SectionHeading title="Read the latest from Brivent." className="mb-12" />

        {remainingPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {remainingPosts.map((post, i) => (
              <motion.div
                key={post.slug}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.06, ease: "easeOut" }}
              >
                <BlogCard post={post} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <p className="text-sm text-muted-light">
              More blog posts will appear here once published.
            </p>
          </div>
        )}
      </Container>
    </section>
  );
}